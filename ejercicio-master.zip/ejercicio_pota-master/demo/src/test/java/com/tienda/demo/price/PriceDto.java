package com.tienda.demo.price;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * Price Dto para utilizar como respuesta del controlador.
 */
public class PriceDto {

	private int productId;
	private int brandId;
	private BigDecimal price;
	private int priceList;
	@JsonFormat(pattern = "yyyy-MM-dd-HH.mm.ss")
	private Date startDate;
	@JsonFormat(pattern = "yyyy-MM-dd-HH.mm.ss")
	private Date endDate;
	
	public int getProductId() {
		return productId;
	}
	
	public void setProductId(int productId) {
		this.productId = productId;
	}
	
	public int getBrandId() {
		return brandId;
	}
	
	public void setBrandId(int brandId) {
		this.brandId = brandId;
	}
	
	public BigDecimal getPrice() {
		return price;
	}
	
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	
	public int getPriceList() {
		return priceList;
	}
	
	public void setPriceList(int priceList) {
		this.priceList = priceList;
	}
	
	public Date getStartDate() {
		return startDate;
	}
	
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

}
