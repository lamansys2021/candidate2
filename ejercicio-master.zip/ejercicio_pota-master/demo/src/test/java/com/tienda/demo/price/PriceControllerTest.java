package com.tienda.demo.price;


import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.web.client.RestTemplate;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class PriceControllerTest {

    @LocalServerPort
    private Integer port;

    private String baseUrl = "http://localhost";


    private static RestTemplate restTemplate = null;

    @BeforeAll
    public static void init() {
        restTemplate = new RestTemplate();
    }

    @BeforeEach
    public void setUp() {
        baseUrl = baseUrl.concat(":").concat(port.toString()).concat("/price");
    }

    /**
     * Test 1: peticion a las 10:00 del dia 14 del producto 35455   para la brand 1 (Tienda)
     */
    @Test
    public void test1() {

    	ResposeDto responseEntity = restTemplate.getForObject(
    			baseUrl.concat("/{productId}/{branchId}?date={date}"), ResposeDto.class,1,35455, "06/14/2020 10:00");
        assertAll(
                () -> assertNotNull(responseEntity),
                () -> assertEquals(1, responseEntity.getPriceList())
        );
    }
    
    /**
     * Test 2: peticion a las 16:00 del dia 14 del producto 35455   para la brand 1 (Tienda)
     */
    @Test
    public void test2() {

    	ResposeDto responseEntity = restTemplate.getForObject(
    			baseUrl.concat("/{productId}/{branchId}?date={date}"), ResposeDto.class,1,35455, "06/14/2020 16:00");
        assertAll(
                () -> assertNotNull(responseEntity),
                () -> assertEquals(2, responseEntity.getPriceList())
        );
    }
    
    /**
     * Test 3: peticion a las 21:00 del dia 14 del producto 35455   para la brand 1 (Tienda)
     */
    @Test
    public void test3() {

    	ResposeDto responseEntity = restTemplate.getForObject(
    			baseUrl.concat("/{productId}/{branchId}?date={date}"), ResposeDto.class,1,35455, "06/14/2020 21:00");
        assertAll(
                () -> assertNotNull(responseEntity),
                () -> assertEquals(1, responseEntity.getPriceList())
        );
    }

    /**
     * Test 4: peticion a las 10:00 del dia 15 del producto 35455   para la brand 1 (Tienda)
     */
    @Test
    public void test4() {

    	ResposeDto responseEntity = restTemplate.getForObject(
    			baseUrl.concat("/{productId}/{branchId}?date={date}"), ResposeDto.class,1,35455, "06/15/2020 10:00");
        assertAll(
                () -> assertNotNull(responseEntity),
                () -> assertEquals(3, responseEntity.getPriceList())
        );
    }
    
    /**
     * Test 5: peticion a las 21:00 del dia 16 del producto 35455   para la brand 1 (Tienda)
     */
    @Test
    public void test5() {

    	ResposeDto responseEntity = restTemplate.getForObject(
    			baseUrl.concat("/{productId}/{branchId}?date={date}"), ResposeDto.class,1,35455, "06/16/2020 21:00");
        assertAll(
                () -> assertNotNull(responseEntity),
                () -> assertEquals(1, responseEntity.getPriceList())                
        );
    }
}
