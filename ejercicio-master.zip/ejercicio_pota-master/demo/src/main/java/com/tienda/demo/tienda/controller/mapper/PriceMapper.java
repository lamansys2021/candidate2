package com.tienda.demo.tienda.controller.mapper;

import org.mapstruct.Mapper;

import com.tienda.demo.tienda.controller.dto.PriceDto;
import com.tienda.demo.tienda.repository.entity.Price;

/**
 * Mapper para la entidad Price
 */
@Mapper
public interface PriceMapper {

	PriceDto toPriceDto(Price price);
}
