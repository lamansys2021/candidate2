package com.tienda.demo.tienda.controller;

import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.tienda.demo.tienda.controller.dto.PriceDto;
import com.tienda.demo.tienda.service.PriceService;

@RestController()
@RequestMapping("/price")
public class PriceController {
	
	@Autowired
	private PriceService service;
	
	/**
	 * Construir una aplicacion/servicio en SpringBoot que provea una end point rest de consulta tal que:
 	 * 	
	 * - Acepte como parametros de entrada: fecha de aplicacion, identificador de producto, identificador de cadena.
	 * 
	 * @param branchId
	 * @param productId
	 * @param date
	 * @return - Devuelva como datos de salida: identificador de producto, identificador de cadena, tarifa a aplicar, fechas de aplicacion y precio final a aplicar.
	 */
	@GetMapping("/{branchId}/{productId}")
	@ResponseBody
	public ResponseEntity<PriceDto> find(
			@PathVariable(value="branchId", required = true) Integer branchId,
				@PathVariable(value="productId", required = true) Integer productId,
					@RequestParam(value="date", required = true) Date date) {
		
		Optional<PriceDto> price = service.find(date, productId, branchId);
		if (price.isPresent()) {
			return ResponseEntity.ok(price.get());	
		}
		return ResponseEntity.notFound().build();
	}

}
