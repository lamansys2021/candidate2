package com.tienda.demo.tienda.repository;

import java.util.Date;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.tienda.demo.tienda.repository.entity.Price;
import com.tienda.demo.tienda.repository.entity.PriceId;

/**
 * Repositorio para la entidad Price
 */
@Repository
public interface PriceRepository extends JpaRepository<Price, PriceId> {
	
	@Query("select p from Price p where p.productId = :productId and p.brandId=:brandId and "
			+ " :date between p.startDate and p.endDate and ROWNUM = 1 Order by p.price asc, p.priority desc")
	Optional<Price> filter(@Param("productId") int productId, @Param("brandId") int brandId, @Param("date") Date date);

}
