package com.tienda.demo.tienda.service.impl;

import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tienda.demo.tienda.controller.dto.PriceDto;
import com.tienda.demo.tienda.controller.mapper.PriceMapper;
import com.tienda.demo.tienda.repository.PriceRepository;
import com.tienda.demo.tienda.repository.entity.Price;
import com.tienda.demo.tienda.service.PriceService;

/**
 * Servicio relacionado a la entidad Price
 */
@Service
public class PriceServiceImpl implements PriceService {

	@Autowired
	private PriceRepository priceRepository;
	
	@Autowired
	private PriceMapper mapper;

	/**
	 * Servicio para la consulta de precios
	 * productId: Id de producto
	 * branchId: id de cadena
	 * dataApplication: fecha de aplicacion.
	 * @return Optional<List<Price>> Lista de precios
	 */
	@Override
	public Optional<PriceDto> find(Date dataApplication, int productId, int branchId) {
		Optional<Price> price = priceRepository.filter(productId, branchId, dataApplication);
		if (price.isPresent()) {
			return Optional.of(mapper.toPriceDto(price.get()));
		}
		return Optional.empty();
	}

}
