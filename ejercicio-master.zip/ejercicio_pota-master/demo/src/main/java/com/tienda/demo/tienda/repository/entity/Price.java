package com.tienda.demo.tienda.repository.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

/**
 * Entidad Price 
 */
@Entity
@IdClass(PriceId.class)
@Table(name = "PRICE")
public class Price implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4124091990436157304L;
	
	/**
	 * foreign key de la cadena del grupo (1 = Tienda).
	 */
	@Id
	@Column(name = "BRAND_ID")
	private int brandId;
	/**
	 * Inicio de fecha en el que aplica el precio tarifa indicado.
	 */
	@Id
	@Column(name = "START_DATE")
	private Date startDate;
	/**
	 * Fin de fechas en el que aplica el precio tarifa indicado.
	 */
	@Id
	@Column(name = "END_DATE")
	private Date endDate;
	/**
	 * Identificador de la tarifa de precios aplicable.
	 */
	@Column(name = "PRICE_LIST")
	private int priceList;
	/**
	 * Identificador codigo de producto.
	 */
	@Column(name = "PRODUCT_ID")
	private int productId;
	/**
	 * Desambiguador de aplicacion de precios. Si dos tarifas coinciden en un rago de fechas se aplica la de mayor prioridad (mayor valor numerico).
	 */
	@Column(name = "PRIORITY")
	private int priority;
	/**
	 * precio final de venta.
	 */
	@Column(name = "PRICE")
	private BigDecimal price;
	/**
	 * iso de la moneda.
	 */
	@Column(name = "CURR")
	private String curr;

	public int getBrandId() {
		return brandId;
	}

	public void setBrandId(int brandId) {
		this.brandId = brandId;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public int getPriceList() {
		return priceList;
	}

	public void setPriceList(int priceList) {
		this.priceList = priceList;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public String getCurr() {
		return curr;
	}

	public void setCurr(String curr) {
		this.curr = curr;
	}

}
