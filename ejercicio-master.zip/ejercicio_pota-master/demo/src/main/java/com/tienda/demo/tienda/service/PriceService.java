package com.tienda.demo.tienda.service;

import java.util.Date;
import java.util.Optional;

import com.tienda.demo.tienda.controller.dto.PriceDto;

public interface PriceService {

	Optional<PriceDto> find(Date fechaAplicacion, 
			int idProducto, int cadena);
}
