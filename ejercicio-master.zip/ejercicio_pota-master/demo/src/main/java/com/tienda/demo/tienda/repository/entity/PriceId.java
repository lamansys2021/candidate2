package com.tienda.demo.tienda.repository.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;

/**
 * Clave primaria para la entidad Prices 
 */
public class PriceId implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8246271075033310016L;
	@Column(name = "START_DATE")
	private Date startDate;
	@Column(name = "END_DATE")
	private Date endDate;
	@Column(name = "PRODUCT_ID")
	private int productId;
	
	public PriceId() {
		
	}
	
	public PriceId(Date startDate, Date endDate, int productId) {
		this.startDate = startDate;
		this.endDate = endDate;
		this.productId = productId;
	}
	
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}

}
